define(function(require, exports, module) {

    var config = {
        //Local files
        url: 'data/',
        //Remote urls
        //url: "https://cssconf.attendease.com/api/"
    };

    return config;
});
