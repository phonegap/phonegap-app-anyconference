define(function(require, exports, module) {

    var SpeakerModel = Backbone.Model.extend({

        initialize: function() {
        }
    });

    return SpeakerModel;
});
